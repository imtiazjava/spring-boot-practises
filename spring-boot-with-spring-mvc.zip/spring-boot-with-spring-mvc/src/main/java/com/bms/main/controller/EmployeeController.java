package com.bms.main.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bms.main.entity.Employee;
import com.bms.main.repository.EmployeeRepsitory;

@Controller
@RequestMapping("/ems-app")
public class EmployeeController {

	@Autowired
	private EmployeeRepsitory erepo;

	@RequestMapping("/")
	public String greeting() {
		return "index";
	}

	@GetMapping("/employees")
	public String getAllEmployees(Model model) {
		model.addAttribute("employees", erepo.findAll());
		return "emp";
	}

	@GetMapping("/new")
	public String newEmployee(Model model) {
		model.addAttribute("employee", new Employee());
		return "emp-form";
	}

	@PostMapping("/save-emp")
	public String saveEmployee(@Valid @ModelAttribute("employee") Employee employee, Errors errors) {
		if (errors.hasErrors()) {
			return "emp-form";
		} else {
			erepo.save(employee);
			return "redirect:/ems-app/employees";
		}
	}

	@GetMapping("/emp-edit/{id}")
	public String saveEmployee(@PathVariable("id") int id, Model model) {
		model.addAttribute("employee", erepo.findById(id).get());
		return "edit-employee";

	}

	@PostMapping("/update-emp/{id}")
	public String updateEmployee(@PathVariable("id") int id, Model model,
			@ModelAttribute("employee") Employee employee) {

		Optional<Employee> op = erepo.findById(id);
		if (op.isPresent()) {
			Employee e = op.get();
			e.setName(employee.getName());
			e.setSalary(employee.getSalary());
			System.out.println(e.getName());
			erepo.save(e);

		}
		return "redirect:/ems-app/employees";
	}

	@GetMapping("/emp-delete/{id}")
	public String deleteEmployee(@PathVariable("id") int id) {
		erepo.deleteById(id);
		return "redirect:/ems-app/employees";

	}
}
