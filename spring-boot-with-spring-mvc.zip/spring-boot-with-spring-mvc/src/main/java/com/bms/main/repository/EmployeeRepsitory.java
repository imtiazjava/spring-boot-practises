package com.bms.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bms.main.entity.Employee;

@Repository
public interface EmployeeRepsitory extends JpaRepository<Employee,Integer>{

}
